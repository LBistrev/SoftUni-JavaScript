// initialization
// find relevant section
// detach section
const section = document.get