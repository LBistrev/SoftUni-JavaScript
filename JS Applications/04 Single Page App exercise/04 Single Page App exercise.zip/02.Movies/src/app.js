// create placeholder modules for every view
// configure and test navigation
// implement modules
// - create async functions for request
// - implement DOM logic

// Order of views:
// - catalog (home view)
// - login / register
// - create
// - details
// - likes
// - edit
// - delete