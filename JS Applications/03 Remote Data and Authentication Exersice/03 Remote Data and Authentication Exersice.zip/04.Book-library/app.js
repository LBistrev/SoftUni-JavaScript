//load all books
// create book
// update book
// delete book

//handle create form
//handle edit form

//load book for editting
// handle delete button

//initialisation

async function request(url, options) {
    if (options.body != undefined) {
        
    }
    const response = await fetch(url, options);

    if (response.ok != true) {
        const error = await response.json()
        alert(error.message);
        throw new Error(error.message);
    }

    const data = await response.json();

    return data;
}

async function loadBooks() {
    const books = await request(`http://localhost:3030/jsonstore/collections/books`)

    return books;
}

async function createBook() {
    const result = await request(`http://localhost:3030/jsonstore/collections/books`, {
        method: 'post',
        headers: { 'Content-Type': 'application/json'},
        body: JSON.stringify(book)
    })

    return result;
}
