function attachEvents() {

    document.getElementById("btnLoad").addEventListener("click", loadContact);
    document.getElementById("btnCreate").addEventListener("click", onCreate);

    loadContact();
}
attachEvents();

const phonebookUl = document.getElementById("phonebook");
const personInput = document.getElementById("person");
const phoneInput = document.getElementById("phone");

function onCreate() {
    const person = personInput.value;
    const phone = phoneInput.value;
    const contact = { person, phone };

    phonebookUl.appendChild(createItem(contact));
}

async function loadContact() {

    const url = `http://localhost:3030/jsonstore/phonebook`;
    const response = await fetch(url);
    const data = await response.json();
    phonebookUl.replaceChildren();

    Object.values(data).map(createItem).forEach(item => phonebookUl.appendChild(item))
}

function createItem(contact) {

    const liElement = document.createElement("li");
    liElement.innerHTML = `${contact.person}: ${contact.phone} <button>Delete</button>`;
    
    return liElement;
}

async function createContacts(contact) {
    const url = `http://localhost:3030/jsonstore/phonebook`;
    const options = {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(contact)
    }
    const response = await fetch(url, options);

    const result = await response.json();

    return result;
}

async function deleteContact(id) {
    const url = 'http://localhost:3030/jsonstore/phonebook/' + id;

    const options = {
        method: "delete"
    }
    const response = await fetch(url, options);

    const result = await response.json();

    return result;
}