function attachEvents() {

    const refreshBtn = document.getElementById("refresh");
    const sendBtn = document.getElementById("submit");

    
    refreshBtn.addEventListener("click", loadMessages);
    sendBtn.addEventListener("click", addMessage);

    loadMessages()
}

const textarea = document.getElementById("messages");
const nameInput = document.querySelector('[name="author"]');
const messageInput = document.querySelector('[name="content"]');

//  add single message to the list
async function addMessage() {
    const name = nameInput.value;
    const message = messageInput.value;

    const result = await createMessage({name, message});

    messageInput.value = "";
    textarea.value += "\n" + `${name}: ${message}`


}

// load and display all messages
async function loadMessages() {

    const url = `http://localhost:3030/jsonstore/messenger`;
    const response = await fetch(url);
    const data = await response.json();

    const messages = Object.values(data);

    
    textarea.value = messages.map(m => `${m.author}: ${m.content}`).join("\n");
}

// post messages
async function createMessage(message) {
    const url = `http://localhost:3030/jsonstore/messenger`;

    const options = {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(message)
    }
    const response = await fetch(url, options);
    const result = await response.json();

    return result;
}

attachEvents();
