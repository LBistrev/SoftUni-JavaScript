window.addEventListener('load', solve);

function solve() {
    const inputModel = document.getElementById("model");
    const inputYear = document.getElementById("year");
    const inputDescription = document.getElementById("description");
    const inputPrice = document.getElementById("price");

    const addBtn = document.getElementById("add");

    addBtn.addEventListener("click", addToTable);


    function addToTable() {
        if (inputModel != "" && inputDescription != "" && inputYear != "" && inputYear.value > 0 && inputPrice != "" && inputPrice.value > 0) {
            let newTr = document.createElement("tr");
            newTr.classList.add("info");
            
        }
    }
}
