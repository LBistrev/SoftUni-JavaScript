const { expect, assert} = require('chai');
const { cinema } = require('./module')

describe('Cinema Tests', () => {
    describe('showMovies method', () => {
        it ("test input with empty array", () => {
            expect(cinema.showMovies([])).to.be.equal("There are currently no movies to show.")
        })
        it ("test input with some movies in array", () => {
            expect(cinema.showMovies(["King Kong" ])).to.deep.equal("King Kong")
            expect(cinema.showMovies(["King Kong", "Joker" ])).to.deep.equal("King Kong, Joker")
        })
    })
    describe('ticketPrice method', () => {
        it("test with valid presentation price", () => {
            expect(cinema.ticketPrice("Premiere")).to.be.equal(12.00)
            expect(cinema.ticketPrice("Normal")).to.be.equal(7.50)
            expect(cinema.ticketPrice("Discount")).to.be.equal(5.50)
        })
        it ("test with invalid present return Error", () => {
            expect(() => cinema.ticketPrice("Invalid present")).to.throw('Invalid projection type.')
        })
        
    })
    describe('swapSeatsInHall method', () => {
        it("test input with invalid first parameter not integer", () => {
            expect(cinema.swapSeatsInHall("a", 1)).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall("", 1)).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(undefined, 1)).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(-1, 1)).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(21, 1)).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(1, 1)).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(0, 1)).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(1)).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(1.5, 1)).to.be.equal("Unsuccessful change of seats in the hall.")
        })
        it("test input with invalid second parameter not integer", () => {
            expect(cinema.swapSeatsInHall(1, "")).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(1, "a")).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(1, undefined)).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(1, -1)).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(1, 21)).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(1, 0)).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(0)).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(1, 1.5)).to.be.equal("Unsuccessful change of seats in the hall.")
        })
        it("test input with invalid parameters not integer", () => {
            expect(cinema.swapSeatsInHall("a", "a")).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(undefined, "a")).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(undefined, [])).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(-1, -1)).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(21, 21)).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(0, 0)).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall()).to.be.equal("Unsuccessful change of seats in the hall.")
        })
        it("test input with invalid parameters not integer", () => {
            expect(cinema.swapSeatsInHall("a", "a")).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(1, "a")).to.be.equal("Unsuccessful change of seats in the hall.")
            expect(cinema.swapSeatsInHall(undefined, [])).to.be.equal("Unsuccessful change of seats in the hall.")
        })
        it("test input with valid parameters not integer", () => {
            expect(cinema.swapSeatsInHall(1, 2)).to.be.equal("Successful change of seats in the hall.")


        })
    })
})