const { expect } = require('chai')
const { pizzUni } = require('./module')

describe('pizzUni test', () => {
    describe('makeOrder method', () => {
        it("check the input", () => {
            let order = {
                orderedPiza: "Margarita",
                drink: "Cola"
            }
            expect(pizzUni.makeAnOrder(order)).to.equal(`You just ordered ${order.orderedPiza} and ${order.drink}`)
        })
    })

    describe('getRemainingWork method', () => {
        
    })

    describe('orderType method', () => {
        
    })
})