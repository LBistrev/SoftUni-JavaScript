function solve() {

    let firstInput = document.querySelector("input[name='lecture-name'")
    let secondInput = document.querySelector("input[name='lecture-date'")
    let thirdInput = document.querySelector("select[name='lecture-module'")

    let lecuturesObj = {};

    const button = document.querySelector("div button")
    button.addEventListener("click", (e) => {
        e.preventDefault();

        if (!firstInput.value == "" && !secondInput.value == "" && thirdInput.value != "Select module") {

            if (!lecuturesObj[thirdInput.value]) {
                lecuturesObj[thirdInput.value] = [];
            }
            let lectureElement = {name: firstInput.value, date: formatDate(secondInput.value)};
            lecuturesObj[thirdInput.value].push(lectureElement);

            createTrainings(lecuturesObj);
        }
    })

    function createTrainings(modules) {

        for (let moduleName in modules) {

            let modulesElement = document.querySelector(".modules");
            modulesElement.innerHTML = "";

            let ulList = document.createElement("ul");
            let moduleElement = createModule(moduleName);

            let lectures = modules[moduleName];
            lectures.sort((a, b) => a.date.localeCompare(b.date))
            lectures.forEach(({name, date}) => {
                ulList.appendChild(createLecture(name, date, moduleName))
            });
            
            moduleElement.appendChild(ulList);
            modulesElement.appendChild(moduleElement);
        }
    }

    function createLecture(name, date) {

        const liElement = document.createElement("li");
        liElement.classList.add("flex");

        let headingElement = document.createElement("h4");
        headingElement.textContent = `${name} - ${date}`;

        const deleteBtn = document.createElement("button");
        deleteBtn.classList.add("red");
        deleteBtn.textContent = "Del";
        deleteBtn.addEventListener("click", (e) => {e.currentTarget.parentElement.remove()});


        liElement.appendChild(headingElement);
        liElement.appendChild(deleteBtn);

        return liElement;
    }

    function createModule(moduleName) {
        let divElement = document.createElement("div");
        divElement.classList.add("module");
        let headingElement = document.createElement("h3");
        headingElement.textContent = `${moduleName.toUpperCase()}-MODULE`;
        divElement.appendChild(headingElement);
        //divElement.appendChild(ulList)

        return divElement;
    }

    function formatDate(dateInput) { 
        "2021-10-28T18:48"
        let [date, time] = dateInput.split("T");
        date = date.replace(/-/g, "/")

        return `${date} - ${time}`
     }
};