class Story {
    constructor(title, creator) {
        this.title = title;
        this.creator = creator;
        this._comments = [];
        this._likes = [];
    }

    get likes() {
        if (this._likes.length == 0) {
            return `${this.title} has 0 likes`
        } 
        let username = this._likes[0]
        if (this._likes.length == 1) {
            
            return `${username} likes this story!`
        }
        this._likes.push(username)
        return `${username} and ${this._likes - 1} others like this story!`
    }

    like(username) {
        if (this._likes.includes(username)) {
            return "You can't like the same story twice!"
        } else if (username === this.creator) {
            "You can't like your own story!"
        } else {
            return `${username} liked ${this.title}!`
        }
    }

    dislike(username) {
        if (!this._likes.includes(username)) {
            "You can't dislike this story!"
        } else {
            return `${username} disliked ${this.title}`
        }
    }

    comment(username, content, id) {
        if (id == undefined || this._comments.some(c => c.id === id) == false) {
            let newComment = {
                id: this._comments.length + 1,
                username,
                content,
                replies: []
            };
            this._comments.push(newComment);
            return `${username} commented on ${this.title}`
        }
        let commentToReply = this._comments.find(c => c.id == id);
        let replyId = Number(commentToReply.id)
        let reply = {
            id: this._comments.length + 1,
            username,
            content,
            replies: []
        };

    }

    toString(sortingType) {

    }
}

let art = new Story("My Story", "Anny");
art.like("John");
console.log(art.likes);
art.dislike("John");
console.log(art.likes);
