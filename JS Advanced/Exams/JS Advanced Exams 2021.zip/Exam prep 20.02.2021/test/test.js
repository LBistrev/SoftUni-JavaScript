const { expect, assert} = require('chai')
const { numberOperations } = require('./module')


describe('numberOperations tests', () => {
    describe('powNumber method', () => {
        it("check if num return num * num", () => {
            expect(numberOperations.powNumber(2)).to.be.equal(4)
        })
        it("check if num is negative return num * num", () => {
            expect(numberOperations.powNumber(-2)).to.be.equal(4)
        })
        it("check with float num return num * num", () => {
            expect(numberOperations.powNumber(5.5)).to.be.equal(5.5 * 5.5)
        })
    })

    describe('numberChecker method', () => {
        it("check if num is not a number", () => {
            expect(numberOperations.numberChecker('1')).to.be.equal('The number is lower than 100!')
            expect(numberOperations.numberChecker('')).to.be.equal('The number is lower than 100!')
        })
        it("check if num is not a number throw error", () => {
            assert.throw(() => numberOperations.numberChecker("str"), Error, 'The input is not a number!')
            assert.throw(() => numberOperations.numberChecker(undefined), Error, 'The input is not a number!')
        })
        it("check if num is greater or equal 100", () => {
            expect(numberOperations.numberChecker(100)).to.be.equal('The number is greater or equal to 100!')
        })
        it("check if num is greater or equal 100", () => {
            expect(numberOperations.numberChecker(101)).to.be.equal('The number is greater or equal to 100!')
        })
    })

    describe('sumArray method', () => {
        it("check sum of arrays indexes", () => {
            expect(numberOperations.sumArrays([1, 2, 3], [1, 2, 3])).to.deep.equal([2, 4, 6])
        })
        it("check sum of arrays indexes", () => {
            expect(numberOperations.sumArrays([1], [1])).to.deep.equal([2])
        })
        it("check empty arrays", () => {
            expect(numberOperations.sumArrays([], [])).to.deep.equal([])
            expect(numberOperations.sumArrays([1, 2], [])).to.deep.equal([1, 2])
        })
        it("check sum with not equals arrays", () => {
            expect(numberOperations.sumArrays([1, 2, 3], [1, 2])).to.deep.equal([2, 4, 3])
        })
    })
})
