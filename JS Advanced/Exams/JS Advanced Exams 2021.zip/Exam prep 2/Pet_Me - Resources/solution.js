function solve() {
    let [inputName, inputAge, inputKind, inputOwner] = Array.from(document.querySelectorAll("#container input"))

    const adpotionSection = document.getElementById("adoption");

    const button = document.querySelector("#container button")
    button.addEventListener("click", addsomeFunc)

    function addsomeFunc(e) {
        e.preventDefault()

        const name = inputName.value;
            const age = inputAge.value;
            const kind = inputKind.value;
            const owner = inputOwner.value;

        if (name == "" == false && !age == "" && !isNaN(Number(age)) && !kind == "" && !owner == "") {

            const contactBtn = e("button", {}, "Contact with owner");

            const pet = e("li", {}, 
                e("p", {},
                    e("strong", {}, name),
                    " is a ",
                    e("strong", {}, age),
                    " year old ",
                    e("strong", {}, kind)
                    ),
                e("span", {}, `Owner: ${owner}`),
                contactBtn
            );
            contactBtn.addEventListener("click", contact)
            adpotionSection.appendChild(pet);

            function contact() {
                const confirmInput = e("input", {placeholder: "Enter your names"})
                const confirmButton = e("button", {}, "Yes! I take it!")
                const confirmationDiv = e("div", {}, 
                    confirmInput,
                    confirmButton
                );

                confirmButton.addEventListener("click", adopt);
                contactBtn.remove();
                pet.appendChild(confirmationDiv);
            }
        }

        function adopt () {

        }

        function e(type, attributes, ...content) {
            const element = document.createElement(type);

            for (let prop in attributes) {
                element[prop] = attributes[prop];
            }

            for (let item of content) {

                if (typeof item == "string" || typeof item == "number") {
                    item = document.createTextNode(item);
                }
                element.appendChild(item);
            }

            return element;
        }
    
    }
}

