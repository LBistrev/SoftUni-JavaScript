function solve() {
    let buttonElement = document.querySelector("#container button")
    let [name, age, kind, owner] = Array.from(document.querySelectorAll("#container input"));
    let adoptionUl = document.querySelector("#adoption ul");
    let adoptedUlElement = document.querySelector("#adopted ul");

    buttonElement.addEventListener("click", e => {
        e.preventDefault();
    })

    if (![name, age, kind, owner].every(x => x.value)) {
        return;
    }
    if (!Number(age.value)) {
        retrun;
    }

    let liElement = document.createElement("li");
    let pElement = document.createElement("p");
    let spanElement = document.createElement("span");
    let btnElement = document.createElement("button");

    pElement.innerHTML = `<strong>${name.value}</strong> is a <strong>${a.value}</strong> year old <strong>${kind.value}</strong>`
    spanElement.textContent = `Owner: ${owner.value}`
    btnElement.textContent = "Contact with owner"

    liElement.appendChild(pElement)
    liElement.appendChild(spanElement)
    liElement.appendChild(btnElement)

    adoptionUl.appendChild(pElement)

    name.value = ""
    age.value = ""
    kind.value = ""
    owner.value = ""

    btnElement.addEventListener("click", petButton)

    function petButton(e) {

        let parent = e.currentTarget.parentElement
        e.currentTarget.remove()

        let divElement = document.createElement("div")

        let inputElement = document.createElement("input")
        inputElement.setAttribute("placeholder", "Enter your names")

        let newBtnElement = document.createElement("button")
        newBtnElement.textContent = "Yes! I take it!"

        divElement.appendChild(inputElement)
        divElement.appendChild(newBtnElement)

        parent.appendChild(divElement)

        newBtnElement.addEventListener("click", ontakeItButtonClick)

    }

    function ontakeItButtonClick(e) {
        let buttonParent = e.currentTarget.parentElement
        let grandLiElement = e.currentTarget.parentElement.parentElement;
        adoptedUlElement.appendChild(grandLiElement)
        let newOwner = grandLiElement.querySelector("input")
        let newOwnerName = newOwner.value
        let ownerSpanElement = grandLiElement.querySelector("span")
        ownerSpanElement.textContent = `New owner ${newOwnerName}`

        let contactBtn = document.querySelector("button")
        contactBtn.textContent = "checked"
        buttonParent.remove()

        grandLiElement.appendChild(contactBtn)

        contactBtn.addEventListener("click", e => {
            e.currentTarget.parentElement.remove()
        })

    }
}