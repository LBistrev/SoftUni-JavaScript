const {expect, assert} = require('chai');
const { testNumbers } = require('./testNumbers')

describe('testNumbers Tests', () => {
    describe('sumNumber method', () => {
        it("test input with invalid parameters", () => {
            expect(testNumbers.sumNumbers("", "")).to.be.undefined
            expect(testNumbers.sumNumbers([], [""])).to.be.undefined
            expect(testNumbers.sumNumbers({}, {})).to.be.undefined
            expect(testNumbers.sumNumbers(1, "a")).to.be.undefined
            expect(testNumbers.sumNumbers("a", 1)).to.be.undefined
        })
        it("test with valid parameters return sum", () => {
            expect(testNumbers.sumNumbers(1, 1)).to.be.equal("2.00")
            expect(testNumbers.sumNumbers(1, 0)).to.be.equal("1.00")
            expect(testNumbers.sumNumbers(1.5, 1.3)).to.be.equal("2.80")
            expect(testNumbers.sumNumbers(0, 1)).to.be.equal("1.00")
            expect(testNumbers.sumNumbers(1, -1)).to.be.equal("0.00")
        })
    })
    describe('numberChecker method', () => {
        it("check if input param is NaN", () => {
            expect(() => testNumbers.numberChecker("a")).to.throw('The input is not a number!')
        })
        it("test with valid param input even number", () => {
            expect(testNumbers.numberChecker(4)).to.be.equal('The number is even!')
            expect(testNumbers.numberChecker(0)).to.be.equal('The number is even!')
            expect(testNumbers.numberChecker("2")).to.be.equal('The number is even!')
        })
        it("test with valid param input odd number", () => {
            expect(testNumbers.numberChecker(1)).to.be.equal('The number is odd!')
            expect(testNumbers.numberChecker("3")).to.be.equal('The number is odd!')
        })
        
    })
    describe('avarageSumArray method', () => {
        it("test the input with valid array returns correct sum", () => {
            expect(testNumbers.averageSumArray([1, 2, 3])).to.be.equal(2)
            expect(testNumbers.averageSumArray([1])).to.be.equal(1)
            expect(testNumbers.averageSumArray([1, 6, -1])).to.be.equal(2)
            expect(testNumbers.averageSumArray([1.5, 2.5, 3.5])).to.be.equal(2.5)
        })
    })
})