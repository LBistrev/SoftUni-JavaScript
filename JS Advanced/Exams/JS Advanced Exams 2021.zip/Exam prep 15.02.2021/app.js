function solution() {
    const input = document.querySelector("input")

    const findSections = document.querySelectorAll("section ul")
    let [listOfGifts, sentGifts, discardedGifts] = findSections

    const button = document.querySelector("button")
    button.addEventListener("click", addGifts)

    function addGifts() {
        
        const name = input.value;
        input.value = "";

        const element = mapper("li", name, "gift");

        const sendBtn = mapper("button", "Send", "sendButton");
        sendBtn.addEventListener("click", () => sendGift(name, element))
        element.appendChild(sendBtn);

        const discardBtn = mapper("button", "Discard", "discardButton");
        discardBtn.addEventListener("click", () => discardGift(name, element))
        element.appendChild(discardBtn);
        
        listOfGifts.appendChild(element);
        sortGifts()

    }

    function sendGift(name, gift) {
        gift.remove();
        const element = mapper("li", name, "gift");
        sentGifts.appendChild(element);
    }

    function discardGift(name, gift) {
        gift.remove();
        const element = mapper("li", name, "gift");
        discardedGifts.appendChild(element);
    }

    function sortGifts() {
        Array.from(listOfGifts.children).sort((a, b) => a.textContent.localeCompare(b.textContent))
        .forEach(gift => listOfGifts.appendChild(gift));
    }

    function mapper(type, content, className) {
        const result = document.createElement(type);
        result.textContent = content;
        if (className) {
            result.className = className
        } 
        return result;
    }

}