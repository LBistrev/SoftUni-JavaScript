const {expect, assert} = require('chai')

const { dealership } = require('./module')

describe('dealership functionality', () => {
    describe('check newCarCost method', () => {

        it ("model not suported return price", () => {
            expect(dealership.newCarCost("not supported", 1)).to.be.equal(1);
        })
        it ("return discount price with supported car", () => {
            expect(dealership.newCarCost('Audi A8 D5', 50000)).be.be.equal(25000);
        })
    })
    describe('check carEquipment method', () => {

        it ("return array with value str", () => {
            expect(dealership.carEquipment(["a"], [0])).to.deep.equal(["a"]);
        })
        it("return the given extras with valid array and valid indexes", () => {
            expect(dealership.carEquipment(["first", "second", "third"], [0, 2])).to.deep.equal(["first", "third"])
        })
        it ("return extra from array with 1 index", () => {
            expect(dealership.carEquipment(["first", "second", "third"], [1])).to.deep.equal(["second"]);
        })
    })
    describe('check euroCategory method', () => {

        it ("check category with value == 4", () => {
            expect(dealership.euroCategory(4)).to.be.equal(`We have added 5% discount to the final price: 14250.`);
        })
        it ("check category with value > 4", () => {
            expect(dealership.euroCategory(5)).to.be.equal(`We have added 5% discount to the final price: 14250.`);
        })
        it ("check category with value < 4", () => {
            expect(dealership.euroCategory(3)).to.be.equal('Your euro category is low, so there is no discount from the final price!');
        })
    })
})