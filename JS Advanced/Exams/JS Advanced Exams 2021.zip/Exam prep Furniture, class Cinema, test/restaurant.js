// create restaurant class with constructor budget  parameter
// load products method - takes one argument (product : array)


class Restaurant {
    constructor(budget){
        this.budgetMoney = budget;
        this.menu = {};
        this.stockProducts = {};
        this.history = [];
    }

    loadProducts(arrAssString){
        for (let data of arrAssString) {
            let [pname, quantity, price] = data.split(' ');
        
            quantity = Number(quantity);
            price = Number(price);

            if (this.budgetMoney < price) {
                this.history.push(`There was not enough money to load ${quantity} ${pname}`)
                return;
            } else if (this.budgetMoney >= price && this.stockProducts[pname] == undefined) {
                this.stockProducts[pname] = quantity
                this.budgetMoney -= price;
            } else if (this.stockProducts[pname] !== undefined) {
                this.stockProducts[pname] += quantity
            }
            this.history.push(`Successfully loaded ${quantity} ${pname}`)

        }
        return this.history.join("\n")
        
    }

    addToMenu(meal, neededProductsAsArray, price){
        let [productName, productQuantity] = neededProductsAsArray.split(" ")
        productQuantity = Number(productQuantity);
        let price = Number(price)

        if (this.menu[meal] == undefined) {
            this.menu[meal] = {
                pro
            }
        }
        for (let [key, value] in Object.entries(this.menu)) {

        }
    }


    showTheMenu(){

    }

    maketheOrder(){

    }
}

let kitchen = new Restaurant(1000);
console.log(kitchen.loadProducts(['Banana 10 5', 'Banana 20 10', 'Strawberries 50 30', 'Yogurt 10 10', 'Yogurt 500 1500', 'Honey 5 50']));