window.addEventListener('load', solve);

function solve() {
    // Get all html elements needed for manipulation
    const modelField = document.getElementById("model");
    const yearField = document.getElementById("year");
    const descriptionField = document.getElementById("description");
    const priceField = document.getElementById("price");


    const addButton = document.getElementById("add");
    addButton.addEventListener("click", addFurniture);

    const furnitureList = document.getElementById("furniture-list");

    // Create addFurniture function that gets all data and creates the properhtml
    function addFurniture(e) {
        e.preventDefault();

        const yearValue = Number(yearField.value)
        const priceValue = Number(priceField.value)
        if (modelField.value != "" && descriptionField.value != "" && yearValue > 0 && priceValue > 0) {
            const tablerow = document.createElement("tr");
            tr.classList.add("info");
            tr.innerHTML = `<td>${modelField.value}</td><td>${priceValue.toFixed(2)}</td><td><button class="moreBtn">More info</button><button class="buyBtn">Buy it</button></td>`;

            const hideTr = document.createElement("tr");
            hideTr.classList.add("hide");
            hideTr.innerHTML = `<td>Year: ${yearValue}</td><td>Description: ${descriptionField.value}<td/>`


            furnitureList.appendChild(tr);
            furnitureList.appendChild(hideTr);

            const moreInfoButton = tr.querySelectAll("button");
            moreInfoButton[0].addEventListener("click", showMoreInfo);
            moreInfoButton[1].addEventListener("click",buyFurniture);
            totalPrice = document.querySelector(".total-price")

        }


    }


    function showMoreInfo(e) {
        const moreInfoTr = e.target.parentElement.parentElement.nexElementSibling;
        if (e.target.textContent == "More info") {
            e.target.textContent = "Less info";
            moreInfoTr.style.display = "contents"
        } else {
            e.target.textContent = "More info"
            moreInfoTr.style.display = "none"
        }
        
        
        

    }

    // Buy functionality on "Buy it button click"
    function buyFurniture() {
        const tr = e.target.parentElement.parentElement;
        const hideTr = tr.nexElementSibling;

        hideTr.parentElement.removeChild(tr);

        const price = Number(tr.querySelectAll("td")[1].textContent);
        totalPrice.textContent = (Number(totalPrice.textContent) + price).toFixed(2);

        td.parentElement.removeChild(tr)
    }

    // Create more info Visualisation and button text function handler






    modelField.value = "";
    yearField.value = "";
    descriptionField.value = "";
    priceField.value = "";
    
    
}
