function delimeter(sequence, symbol) {
    console.log(sequence.join(symbol))
}

delimeter(['How about no?', 'I','will', 'not', 'do', 'it!'], '_')
delimeter(['One', 'Two', 'Three', 'Four', 'Five'], '-')
